"""
End‑to‑end test using the Playwright Page Object Model.

This test opens the Playwright documentation home page via the ``HomePage``
object, verifies the hero title contains the word "Playwright" and clicks the
"Get started" link.  It asserts that the URL changes after the click.
"""

import pytest

pytest.importorskip("playwright.sync_api")

from src.pages.home_page import HomePage


@pytest.mark.e2e
def test_playwright_home_page(page) -> None:
    home = HomePage(page)
    home.goto()
    # Check that the hero title element contains the word Playwright
    assert "Playwright" in home.hero_title().inner_text()
    # Click the Get started link and wait for navigation
    home.click_get_started()
    page.wait_for_load_state("networkidle")
    # After clicking, the URL should contain 'docs'
    assert "docs" in page.url