# QA Automation Demo: Python with PyTest, Playwright, Schemathesis & Locust

I built this repository to demonstrate how I design a production‑ready QA automation framework in Python. The project uses PyTest for test execution, Playwright for browser automation, SQLAlchemy for ORM, Flask for a mock API, Schemathesis for contract testing and Locust for performance testing. My goal is to show how I layer tests across unit, API, database, UI and contract and how to extend the framework with load, security and contract tests.

## Features

- **Unit & component tests with PyTest** – I write concise tests that validate the core business logic in `src/calc.py` and other helpers in isolation. Fixtures and parametrisation make these tests expressive and reusable.

- **API tests using Requests & mocking** – My `api_client.py` wraps `requests` and exposes a function to fetch posts from JSONPlaceholder. The tests assert status codes and response structures while using `pytest-mock` to isolate the HTTP call or hitting the local mock API when needed.

- **Mock server** – I provide a lightweight Flask mock API in `mock/server.py` that serves sample JSON from `mock/data.json`. This allows offline development and deterministic API tests. The server implements `GET /posts` and `GET /posts/{id}` as well as a health check endpoint.

- **Database & repository layer** – I use SQLite together with SQLAlchemy in `src/db.py` to define a simple `User` model. The repository class in `src/repositories/user_repository.py` encapsulates queries and seeding for database tests.

- **Playwright Page Object Model** – The POM class in `src/pages/home_page.py` encapsulates selectors and actions for the Playwright docs site. This abstraction keeps my end‑to‑end tests maintainable.

- **End‑to‑end tests across browsers** – The `tests/e2e` directory contains cross‑browser E2E tests using Playwright’s sync API, configured to run in Chromium, Firefox and WebKit. The tests verify content and navigation on real public sites (`example.com` and the Playwright docs).

- **Contract testing with Schemathesis** – I define an OpenAPI specification for the mock API in `contract/openapi.yaml` and run Schemathesis against it. This generates property‑based tests that verify the API adheres to the contract.

- **Load testing with Locust** – The `performance/locustfile.py` defines a simple Locust load test against the mock API. Running `locust -f performance/locustfile.py` spawns virtual users and reports performance metrics.

- **Security testing placeholder** – I include a skeleton test that can run an OWASP ZAP scan against the mock API. It demonstrates how to hook into ZAP’s Python API; you can skip or expand this test once ZAP is installed.

- **Configuration & fixtures** – `pytest.ini` configures default markers and test paths. Shared fixtures in `conftest.py` spin up the database, seed data and provide a patched API client for unit tests.

- **CI‑ready structure** – The repository is laid out for easy integration with CI/CD pipelines. You can run `pytest` for all tests or use markers to scope runs (`pytest -m e2e`).

## Project structure

```
mock/
├── data.json        # Seed data for the mock API
├── server.py        # Flask server serving mock endpoints

src/
├── api_client.py               # HTTP client using requests
├── calc.py                     # Calculator module
├── db.py                       # SQLAlchemy models and helper
├── pages/
│   └── home_page.py            # Playwright POM for docs site
├── repositories/
│   └── user_repository.py      # Repository abstraction for users

contract/
└── openapi.yaml                # OpenAPI specification for the mock API

performance/
└── locustfile.py               # Locust load test script

tests/
├── api/
│   └── test_posts.py           # API tests for api_client and mock server
├── db/
│   └── test_users.py           # DB tests using SQLAlchemy & repository
├── e2e/
│   ├── test_example.py         # Cross‑browser E2E test for example.com
│   └── test_home.py            # E2E test using POM for Playwright docs
├── unit/
│   └── test_calc.py            # Unit tests for calculator
├── contract/
│   └── test_contract.py        # Schemathesis contract tests
├── performance/
│   └── test_load.py            # Wrapper to launch locust (optional)
└── security/
    └── test_security.py        # Skeleton for OWASP ZAP security scan

conftest.py            # Shared PyTest fixtures
pytest.ini             # PyTest configuration
requirements.txt       # Python dependencies
```

## Getting started

1. **Install dependencies**:
   ```bash
   pip install -r requirements.txt
   ```

2. **Run unit, API, DB and contract tests**:
   ```bash
   pytest -m "unit or api or db or contract"
   ```
   or simply `pytest` to run everything except performance, security and e2e tests.

3. **Run end‑to‑end tests**:
   ```bash
   pytest -m e2e
   ```
   The E2E tests use Playwright’s sync API and run headless by default. Set the `PLAYWRIGHT_HEADFUL=1` environment variable to see the browser.

4. **Start the mock API**:
   ```bash
   python mock/server.py
   ```
   This starts a Flask server at http://localhost:5000 serving endpoints defined in `mock/data.json`.

5. **Run contract tests**:
   ```bash
   pytest -m contract
   ```
   Schemathesis will generate requests to exercise all operations defined in the OpenAPI file.

6. **Run load tests**:
   ```bash
   locust -f performance/locustfile.py
   ```
   Open the Locust web UI at http://localhost:8089, enter the target host (e.g. http://localhost:5000) and start the test.

7. **Run security tests**:
   ```bash
   pytest -m security
   ```
   These tests will be skipped unless the OWASP ZAP Python API is installed and the ZAP daemon is running.

## Notes

- I keep my tests deterministic by seeding the in‑memory SQLite database before each run and using a local mock API.
- The Page Object Model pattern encapsulates UI selectors and actions to reduce maintenance.
- You can extend this framework by adding more POM classes, API endpoints, or migrating to a different database without changing tests.