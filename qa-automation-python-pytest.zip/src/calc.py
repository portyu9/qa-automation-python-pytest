def add(a: float, b: float) -> float:
    """
    Add two numbers and return the result.

    Args:
        a: First operand.
        b: Second operand.

    Returns:
        The sum of ``a`` and ``b``.
    """
    return a + b


def subtract(a: float, b: float) -> float:
    """
    Subtract the second number from the first and return the result.

    Args:
        a: First operand.
        b: Second operand.

    Returns:
        The difference ``a - b``.
    """
    return a - b


def multiply(a: float, b: float) -> float:
    """
    Multiply two numbers and return the product.

    Args:
        a: First operand.
        b: Second operand.

    Returns:
        The product of ``a`` and ``b``.
    """
    return a * b


def divide(a: float, b: float) -> float:
    """
    Divide the first number by the second and return the result.

    Args:
        a: Numerator.
        b: Denominator.

    Returns:
        The quotient ``a / b``.

    Raises:
        ValueError: If an attempt is made to divide by zero.
    """
    if b == 0:
        raise ValueError("Cannot divide by zero")
    return a / b