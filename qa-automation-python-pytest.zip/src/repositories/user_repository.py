"""
Repository abstraction for the ``User`` model.

I encapsulate database operations in this repository so my tests don’t need to
construct SQLAlchemy queries directly.  This pattern makes it trivial to
replace or extend the underlying storage without changing the tests.
"""

from __future__ import annotations

from sqlalchemy.orm import Session

from ..db import get_engine, init_db, User


class UserRepository:
    """Repository layer for ``User`` database operations."""

    def __init__(self, session: Session) -> None:
        self.session = session

    @classmethod
    def initialize(cls, db_url: str = "sqlite:///qa_users.db") -> "UserRepository":
        """
        Initialise the repository by creating an engine, seeding data and
        returning a session‑wrapped repository.

        Args:
            db_url: Database URL string for SQLite.  Defaults to file‑based
                ``qa_users.db``.

        Returns:
            A configured ``UserRepository`` instance with an active session.
        """
        engine = get_engine(db_url=db_url)
        # ensure the database schema exists and seed sample data
        init_db(engine)
        session = Session(bind=engine)
        return cls(session)

    def find_all(self):
        """
        Retrieve all users ordered by their primary key.

        Returns:
            list[User]: All user records from the database.
        """
        return self.session.query(User).order_by(User.id).all()

    def find_by_id(self, user_id: int):
        """
        Retrieve a single user by id.

        Args:
            user_id: The primary key of the user.

        Returns:
            User | None: The user record if found, otherwise None.
        """
        return self.session.query(User).filter(User.id == user_id).one_or_none()

    def close(self) -> None:
        """
        Close the underlying session.

        It’s good practice to explicitly close sessions when the repository is
        no longer needed.
        """
        self.session.close()