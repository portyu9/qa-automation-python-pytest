"""
Simple HTTP client wrapper used in API tests.

I wrap ``requests`` in a function so that my tests can mock HTTP calls easily
and my API base URL can be configured via the ``API_BASE_URL`` environment
variable.  By default the client targets the public JSONPlaceholder service.
"""

from __future__ import annotations

import os
from typing import List, Dict, Any

import requests

# Allow tests to override the base URL via an environment variable.  Falling
# back to the public JSONPlaceholder service keeps the client functional when
# no local mock server is running.
BASE_URL: str = os.environ.get(
    "API_BASE_URL", "https://jsonplaceholder.typicode.com"
)


def fetch_posts() -> List[Dict[str, Any]]:
    """
    Fetch posts from the configured service and return the JSON data.

    I use this helper in my API tests to validate status codes and response
    structures.  Tests can patch ``requests.get`` or override ``API_BASE_URL``
    to point at a local mock server.

    Returns:
        A list of post objects represented as dictionaries.

    Raises:
        requests.HTTPError: If the HTTP request failed or returned a non‑200 status.
    """
    response = requests.get(f"{BASE_URL}/posts")
    response.raise_for_status()
    return response.json()