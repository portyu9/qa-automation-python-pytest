"""
Database helper and ORM models.

I use SQLAlchemy's declarative base to define a simple ``User`` model and
convenience functions for initialising an in‑memory SQLite database.  The
``init_db`` function seeds the database with a few users to make tests
deterministic.
"""

from __future__ import annotations

from typing import List

from sqlalchemy import create_engine, Column, Integer, String
from sqlalchemy.orm import declarative_base, sessionmaker, Session
from sqlalchemy.engine import Engine


# Base class for ORM models
Base = declarative_base()


class User(Base):
    """
    ORM model representing a user record in the database.  I define this here so
    that my tests can insert and query users with SQLAlchemy while keeping the
    schema explicit.
    """

    __tablename__ = "users"
    id = Column(Integer, primary_key=True)
    name = Column(String)
    email = Column(String)


def get_engine(echo: bool = False, db_url: str = "sqlite:///:memory:") -> Engine:
    """
    Create a new SQLite engine.

    By default this returns an in‑memory engine, but a different database URL
    can be provided.  The ``echo`` flag prints SQL statements for debugging when
    set to True.

    Args:
        echo: If True, engine will log all statements to stdout.
        db_url: Database URL string for SQLAlchemy.

    Returns:
        A SQLAlchemy Engine instance.
    """
    return create_engine(db_url, echo=echo, future=True)


def init_db(engine: Engine) -> None:
    """
    Create all tables defined on the Base metadata and seed initial users.

    This function is idempotent and can be called multiple times.  It opens a
    short‑lived session to insert sample users.

    Args:
        engine: The SQLAlchemy engine used to create tables and sessions.
    """
    # Create tables
    Base.metadata.create_all(engine)

    # Open a session and insert sample users
    SessionLocal = sessionmaker(bind=engine, future=True)
    with SessionLocal() as session:
        session.add_all([
            User(name="Alice", email="alice@example.com"),
            User(name="Bob", email="bob@example.com"),
            User(name="Charlie", email="charlie@example.com"),
        ])
        session.commit()


def get_all_users(session: Session) -> List[User]:
    """
    Retrieve all users from the database ordered by their id.

    Args:
        session: An active SQLAlchemy session bound to a database.

    Returns:
        A list of ``User`` instances.
    """
    return session.query(User).order_by(User.id).all()